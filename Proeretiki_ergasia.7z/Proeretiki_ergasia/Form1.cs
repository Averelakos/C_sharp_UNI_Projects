﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Iraklis Tsikas 
//AM: MPPL20082
namespace Proeretiki_ergasia
{
    public partial class Form1 : Form
    {
        Random random;
        Boolean play;
        int redX, redY;
        int whiteX,whiteY;
        Boolean drag = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }
        private Point redmove;

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            redmove = e.Location;
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            redX = pictureBox4.Location.X;
            redY = pictureBox4.Location.Y;
            if (drag == true)
            {
                
                pictureBox4.Location = new Point(redX + e.X-redmove.X, redY +e.Y-redmove.Y);
            }
        }

        private void pictureBox4_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private Point whitemove;
        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            whitemove = e.Location;
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            whiteX = pictureBox5.Location.X;
            whiteY = pictureBox5.Location.Y;
            if (drag == true)
            {
                pictureBox5.Location = new Point(whiteX + e.X - whitemove.X, whiteY + e.Y - whitemove.Y);
            }
        }

        private void pictureBox5_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            random = new Random();
            int Dice1 = random.Next(1, 7);
            int Dice2 = random.Next(1, 7);
            int count = 0;
            
            switch (Dice1)
            {
                case 1:
                    count = 1;
                    pictureBox2.Image = Properties.Resources._1;
                    break;
                case 2:
                    count = 2;
                    pictureBox2.Image = Properties.Resources._2;
                    break;
                case 3:
                    count = 3;
                    pictureBox2.Image = Properties.Resources._3;
                    break;
                case 4:
                    count = 4;
                    pictureBox2.Image = Properties.Resources._4;
                    break;
                case 5:
                    count = 5;
                    pictureBox2.Image = Properties.Resources._5;
                    break;
                case 6:
                    count = 6;
                    pictureBox2.Image = Properties.Resources._6;
                    break;

            }
            switch (Dice2)
            {
                case 1:
                    count = count+1;
                    pictureBox3.Image = Properties.Resources._1;
                    break;
                case 2:
                    count = count + 2;
                    pictureBox3.Image = Properties.Resources._2;
                    break;
                case 3:
                    count = count + 3;
                    pictureBox3.Image = Properties.Resources._3;
                    break;
                case 4:
                    count = count + 4;
                    pictureBox3.Image = Properties.Resources._4;
                    break;
                case 5:
                    count = count + 5;
                    pictureBox3.Image = Properties.Resources._5;
                    break;
                case 6:
                    count = count + 6;
                    pictureBox3.Image = Properties.Resources._6;
                    break;

            }

            textBox1.Text = count.ToString();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
           
        }
    }
}
